function validate1() {
    var firstNameCheck = letterCheck(document.forms["information"]["firstName"].value);
    var imageFirstName = getImage(firstNameCheck, "firstName");

    var lastNameCheck = letterCheck(document.forms["information"]["lastName"].value);
    var imageLastName = getImage(lastNameCheck, "lastName");

    var genderCheck = notSelected(document.forms["information"]["gender"].value);
    var imageGender = getImage(genderCheck, "gender");
    
    var stateCheck = notSelected(document.forms["information"]["state"].value);
    var imageState = getImage(stateCheck, "state");

    document.getElementById("FirstName").appendChild(imageFirstName);
    document.getElementById("LastName").appendChild(imageLastName);
    document.getElementById("Gender").appendChild(imageGender);
    document.getElementById("State").appendChild(imageState);

    var currentUrl = window.location.href; 
    var temp = currentUrl.split(""); 

    var i;
    for (i = currentUrl.length - 4; i >= 0; i--) { 
        if (temp[i] == '/') {
            break;
        }
    }

    currentUrl = currentUrl.slice(0, i); // get rid of old url
    currentUrl += "/validation2.html"; // add url to validation2

    if (firstNameCheck && lastNameCheck && genderCheck && stateCheck) {
        window.location = currentUrl; // goes to new url if all checks pass
    }
}

 // get rid of cookies
 function deleteCookie(name) {
    document.cookie = name + '=; expires=Thu, 01 Jan 1970 00:00:01 GMT;';
}

// Given to us
function getImage(bool, ID) {
    var image = document.getElementById("image" + ID);
    if (image == null) {
        image = new Image(15, 15);
        image.id = "image" + ID;
    }
    image.src = bool ? './correct.png' : './wrong.png';
    return image;
}

// Given to us
function alphaNumCheck(entry) {
    let regex = /^[a-z0-9]+$/i;
    if (entry != null && entry.match(regex)) {
        return true;
    }
    else {
        return false;
    }

}

// Check if letters
function letterCheck(entry) {
    let regex = /^[a-z]+$/i;
    if (entry.match(regex) && entry != null) {
        return true;
    } else {
        return false;
    }
}

// Check if option chosen
function notSelected(entry) {
    if (entry == "select") {
        return false;
    }
    else {
        return true;
    }
}
