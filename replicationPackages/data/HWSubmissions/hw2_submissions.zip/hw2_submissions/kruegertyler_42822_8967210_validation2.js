function validate2() {
    var emailImage = getImage(emailCheck(document.forms["contact information"]["email"].value), "email");
    document.getElementById("Email").appendChild(emailImage);
    var phoneImage = getImage(phoneCheck(document.forms["contact information"]["number"].value), "phone");
    document.getElementById("Phone").appendChild(phoneImage);
    var addressImage = getImage(addressCheck(document.forms["contact information"]["address"].value), "address");
    document.getElementById("Address").appendChild(addressImage);

}

// deletes cookies
function deleteCookie(name) {
    document.cookie = name + '=; expires=Thu, 01 Jan 1970 00:00:01 GMT;';
}

// Given to us
function getImage(bool, ID) {
    var image = document.getElementById("image" + ID);
    if (image == null) {
        image = new Image(15, 15);
        image.id = "image" + ID;
    }
    image.src = bool ? './correct.png' : './wrong.png';
    return image;
}

// Given to us
function emailCheck(email) {
    atSplit = email.split('@');
    if (atSplit.length == 2 && alphaNumCheck(atSplit[0])) {
        periodSplit = atSplit[1].split('.')
        if (periodSplit.length == 2 && alphaNumCheck(periodSplit[0] + periodSplit[1])) {
            return true;
        }
    }
    return false;
}

// Given to us
function alphaNumCheck(entry) {
    let regex = /^[a-z0-9]+$/i;
    if (entry != null && entry.match(regex)) {
        return true;
    } else {
        return false;
    }
}

// Checks for only letters
function letterCheck(entry) {
    let regex = /^[a-z]+$/i;
    if (entry != null && entry.match(regex)) {
        return true;
    } else {
        return false;
    }
}

// Checks for only numbers
function numberCheck(entry) {
    let regex = /^[0-9]+$/i;
    if (entry != null && entry.match(regex)) {
        return true;
    } else {
        return false;
    }
}

// Validates the phone number.
function phoneCheck(entry) {
    var phone, i;

    if (entry.length == 10) {
        return numberCheck(entry);
    }
    else if (entry.length == 12) {
        phone = entry.split('-');
    }
    else {
        return false;
    }

    if (phone[0].length == 3 && phone[1].length == 3 && phone[2].length == 4 && phone.length == 3) {
        for (i = 0; i < 3; i++) {
            if (!numberCheck(phone[i])){
                 return false;
            }
        }
        return true;
    } 
    else {
        return false;
    }
}

// Validates the address.
function addressCheck(entry) {
    if (entry == null) {
        return false;
    }
    var address;

    address = entry.split(',');
    if (address.length == 2 && letterCheck(address[0].trim()) && letterCheck(address[1].trim())){
         return true;
    }
    else{ 
        return false;
    }
}


